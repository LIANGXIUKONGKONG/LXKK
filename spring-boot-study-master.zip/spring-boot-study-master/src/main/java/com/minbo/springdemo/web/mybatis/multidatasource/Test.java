package com.minbo.springdemo.web.mybatis.multidatasource;

/**
 * 待验证
 */
public class Test {
	/**
	 * 多数据源配置：
	 * 参考资料：https://github.com/mybatis/spring-boot-starter/issues/78
	*/
	
	/**
	 * Sql查询分页插件
	 * 参考资料：http://blog.csdn.net/catoop/article/details/50553714
	 * Github项目地址： https://github.com/pagehelper/Mybatis-PageHelper
	 */
}
