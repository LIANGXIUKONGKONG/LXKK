package com.minbo.springdemo.web.mybatis.xml;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
//public class SampleXmlApplication implements CommandLineRunner {
//
//	@Autowired
//	private CityDao cityDao;
//
//	@Autowired
//	private HotelMapper hotelMapper;
//	
//	public static void main(String[] args) {
//		SpringApplication.run(SampleXmlApplication.class, args);
//	}
//
//	@Override
//	public void run(String... args) throws Exception {
//		System.out.println(this.cityDao.selectCityById(1));
//		System.out.println(this.hotelMapper.selectByCityId(1));
//	}
//
//}
