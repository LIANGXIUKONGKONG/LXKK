package com.md.core.leafid.snowflake.exception;

public class CheckOtherNodeException extends RuntimeException {
	private static final long serialVersionUID = -3875889640476871473L;

	public CheckOtherNodeException(String message) {
        super(message);
    }
}
