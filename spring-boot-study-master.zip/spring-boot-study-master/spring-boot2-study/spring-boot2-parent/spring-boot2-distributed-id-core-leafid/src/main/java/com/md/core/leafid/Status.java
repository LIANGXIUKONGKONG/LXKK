package com.md.core.leafid;

public enum  Status {
    SUCCESS,
    EXCEPTION
}
