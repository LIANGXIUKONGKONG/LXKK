package com.md.demo.service;

public interface DemoService {
	String sayHello(String name);
}
