package com.md.demo.service;

public class DemoServiceImpl implements DemoService{

	public String sayHello(String name) {
		return "Welcome to Minbo's Dubbo demo, Hello " + name;
	}

}
