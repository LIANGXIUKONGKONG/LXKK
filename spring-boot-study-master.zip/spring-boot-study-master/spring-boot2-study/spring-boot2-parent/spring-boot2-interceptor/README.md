# spring-boot2-interceptor

【拦截器】技术点

功能介绍

1. 拦截器用法介绍
2. 如何把服务层对象注入到拦截器中，调用相关方法
3. 开启跨域访问功能

## 本项目教程

[拦截器用法和场景案例分析](https://blog.csdn.net/hemin1003/article/details/90242803)

## 该系列教程

[SpringBoot2系列](https://blog.csdn.net/hemin1003/column/info/40170)


## 个人说明

期望和大家”一起学习，一起成长“，共勉，O(∩_∩)O谢谢

不讲虚的，只做实干家

Talk is cheap，show me the code

<br/>


## [关于我](http://heminit.com/about/)

欢迎交流问题，可加我的个人QQ 469580884，或Q群号 751925591，一起探讨交流问题

[我的博客地址](http://blog.csdn.net/hemin1003)

[个人域名](http://heminit.com)