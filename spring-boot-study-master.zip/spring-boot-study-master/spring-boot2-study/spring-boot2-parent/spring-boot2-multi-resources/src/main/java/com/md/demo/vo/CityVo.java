package com.md.demo.vo;

import com.md.demo.bo.City;

public class CityVo extends City {

	private static final long serialVersionUID = 1L;

}
