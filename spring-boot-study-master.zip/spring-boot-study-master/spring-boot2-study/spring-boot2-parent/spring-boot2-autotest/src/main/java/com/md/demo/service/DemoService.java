package com.md.demo.service;

public interface DemoService {
	
	public String sayHello();
}
